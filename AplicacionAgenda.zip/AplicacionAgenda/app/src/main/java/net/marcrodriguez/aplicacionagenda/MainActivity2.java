package net.marcrodriguez.aplicacionagenda;

import android.content.Intent;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    EditText usu,mail,twi,tel,fech;
    Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btn2 = (Button)findViewById(R.id.aceptar);
        usu = (EditText)findViewById(R.id.usuario);
        mail = (EditText)findViewById(R.id.email);
        twi = (EditText)findViewById(R.id.twitter);
        tel = (EditText)findViewById(R.id.telefono);
        fech = (EditText)findViewById(R.id.fecha);



        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myint2 = new Intent();
                Contacto cont =new Contacto(usu.getText().toString(),mail.getText().toString(),twi.getText().toString(),tel.getText().toString(),fech.getText().toString())
;
                myint2.putExtra("marco",cont);
                setResult(RESULT_OK,myint2);
                finish();

            }
        });



    }

}
