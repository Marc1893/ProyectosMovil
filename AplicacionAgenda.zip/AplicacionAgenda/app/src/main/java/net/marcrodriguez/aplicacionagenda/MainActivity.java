package net.marcrodriguez.aplicacionagenda;

import android.content.Intent;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView list;
    Button btn;
    ArrayList <Contacto> listaCom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button)findViewById(R.id.agregar);
        list = (ListView)findViewById(R.id.lista);
        listaCom = new ArrayList<>();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myint = new Intent(getApplication(),MainActivity2.class);
                startActivityForResult(myint,2);


            }
        });


    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==2  && resultCode==RESULT_OK){

            Contacto cont =  (Contacto) data.getSerializableExtra("marco");
            listaCom.add(cont);

            String [] agregados = new String[listaCom.size()];
            for (int i = 0; i<agregados.length;i++){
                agregados[i]= listaCom.get(i).toString();
            }

            ArrayAdapter <String> adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,agregados);
            list.setAdapter(adaptador);


        }

    }




}
