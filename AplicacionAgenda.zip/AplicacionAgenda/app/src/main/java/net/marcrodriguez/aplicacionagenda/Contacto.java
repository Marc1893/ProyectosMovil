package net.marcrodriguez.aplicacionagenda;

import java.io.Serializable;

/**
 * Created by Marc on 05/09/17.
 */

public class Contacto implements Serializable {
    private String Usario;
    private String Email;
    private String Twitter;
    private String Numero;
    private String Fecha;

    public Contacto(String usario, String email, String twitter, String numero, String fecha) {
        Usario = usario;
        Email = email;
        Twitter = twitter;
        Numero = numero;
        Fecha = fecha;
    }

    @Override
    public String toString() {
        return Usario+"\n"+ Email;

    }
}
