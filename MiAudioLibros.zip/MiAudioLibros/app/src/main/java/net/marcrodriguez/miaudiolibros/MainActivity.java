package net.marcrodriguez.miaudiolibros;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ArrayAdapter;

import net.marcrodriguez.miaudiolibros.Fragments.DetalleFragment;
import net.marcrodriguez.miaudiolibros.Fragments.SelectorFragment;

public class MainActivity extends AppCompatActivity {

    RecyclerView r_v;
    AdaptadorLibros adp;
    RecyclerView.LayoutManager lmrv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.containt_main);

        if ((findViewById(R.id.contenedor_pequeno) != null) && (getSupportFragmentManager().findFragmentById(R.id.contenedor_pequeno) == null)){

            SelectorFragment primerFragment = new SelectorFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.contenedor_pequeno, primerFragment).commit();

        }







        //r_v = (RecyclerView)findViewById(R.id.recyclerView);
        //InfoGlobal info = InfoGlobal.getInstance();
        //info.inicializa(this);

        //adp = new AdaptadorLibros(this, info.getVectorLibros());

        //adp.setOnItemClickListener(new View.OnClickListener(){

        //    @Override
        //    public void onClick(View view){

        //      Toast.makeText(getApplication(), String.valueOf(r_v.getChildAdapterPosition(view)), Toast.LENGTH_SHORT).show();



        //    }

        //});

        //r_v.setAdapter(adp);
        //lmrv = new GridLayoutManager(this,2);
        //r_v.setLayoutManager(lmrv);





    }


    public void mostrarDetalle(int id) {

        DetalleFragment detalleFragment = (DetalleFragment) getSupportFragmentManager().findFragmentById(R.id.detalle_fragment);

        if (detalleFragment != null) {

            detalleFragment.ponInfoLibro(id);

        } else {

            DetalleFragment nuevoFragment = new DetalleFragment();
            Bundle args = new Bundle();
            args.putInt(DetalleFragment.ARG_ID_LIBRO, id);
            nuevoFragment.setArguments(args);
            FragmentTransaction transaccion = getSupportFragmentManager().beginTransaction();
            transaccion.replace(R.id.contenedor_pequeno, nuevoFragment);
            transaccion.addToBackStack(null);
            transaccion.commit();

        }

    }

}
