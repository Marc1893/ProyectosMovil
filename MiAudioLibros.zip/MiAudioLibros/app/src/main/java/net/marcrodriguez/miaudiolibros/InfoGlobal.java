package net.marcrodriguez.miaudiolibros;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import java.util.Vector;

/**
 * Created by Marc on 12/09/17.
 */

public class InfoGlobal {

    private Vector<Libro> vectorLibros;
    private AdaptadorLibros adaptador;


    private static InfoGlobal INSTANCIA = new InfoGlobal();

    private InfoGlobal() {}

    public static InfoGlobal getInstance(){

        return INSTANCIA;

    }


    public void inicializa(Context contexto){

        vectorLibros = Libro.ejemploLibros();
        adaptador = new AdaptadorLibros(contexto, vectorLibros);

    }


    public AdaptadorLibros getAdaptador() {
        return adaptador;
    }


    public Vector<Libro> getVectorLibros() {
        return vectorLibros;
    }






}
